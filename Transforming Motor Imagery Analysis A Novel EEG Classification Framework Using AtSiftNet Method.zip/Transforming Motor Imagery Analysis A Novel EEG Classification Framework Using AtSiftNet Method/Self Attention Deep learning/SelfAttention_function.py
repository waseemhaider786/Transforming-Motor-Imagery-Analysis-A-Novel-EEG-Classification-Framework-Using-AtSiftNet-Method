# -*- coding: utf-8 -*-
"""
Created on Thu Oct 12 18:38:09 2023

@author: wasee
"""



import torch
import torch.nn as nn


class SelfAttention(nn.Module):
    def __init__(self, input_dim):
        super(SelfAttention, self).__init__()
        
        self.query = nn.Linear(input_dim, input_dim)
        self.key = nn.Linear(input_dim, input_dim)
        self.value = nn.Linear(input_dim, input_dim)
        
    def forward(self, x):
        # Apply linear transformations to get query, key, and value tensors
        query = self.query(x)
        key = self.key(x)
        value = self.value(x)
        
        # Compute scaled dot-product attention
        attention_scores = torch.matmul(query, key.transpose(1, 2))
        attention_scores = attention_scores / (x.size(-1) ** 0.5)
        attention_weights = torch.nn.functional.softmax(attention_scores, dim=-1)
        
        # Weighted sum of values using attention weights
        output = torch.matmul(attention_weights, value)
        
        return output