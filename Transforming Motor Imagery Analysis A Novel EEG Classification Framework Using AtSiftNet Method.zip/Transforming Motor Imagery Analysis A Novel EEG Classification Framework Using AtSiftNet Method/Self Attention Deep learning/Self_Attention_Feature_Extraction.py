# -*- coding: utf-8 -*-
"""
Created on Wed Oct 11 19:49:38 2023

@author: wasee
"""


import pandas as pd
import numpy as np
import SelfAttention_function
import torch
from sklearn.model_selection import train_test_split
import Random_forest_classifier




# Read the CSV files
from_class_1 = pd.read_csv('F:/Course Ms/Research/MATLAB/From CSV/My orginal/Preprocessed CSV/Preprocessed_Class_1.csv')
from_class_2 = pd.read_csv('F:/Course Ms/Research/MATLAB/From CSV/My orginal/Preprocessed CSV/Preprocessed_Class_2.csv')









#Take only one Epox
intial_index__class_1=0
final_index_class_1 = 350

new_list_collection_class_1 = []


#For Class 1 Feature Extraction Using Self Attention
for i in range(0,80):
    # Example usage:
    input_dim_class_1 = 18
    seq_length_class_1 = 350

    Extracted_Epox_class_class_1 = from_class_1.iloc[intial_index__class_1: final_index_class_1, :].reset_index(drop=True)
    your_data_df_class_1 = Extracted_Epox_class_class_1
    # Convert the DataFrame to a PyTorch tensor
    input_data_class_1 = torch.tensor(your_data_df_class_1.values, dtype=torch.float32)
    # Initialize the self-attention module
    self_attention_class_1 = SelfAttention_function.SelfAttention(input_dim_class_1)
    
    
    
    # Apply self-attention to your data
    output = self_attention_class_1(input_data_class_1.unsqueeze(1))
    # Reshape the output to the desired shape [350, 18]
    output = output.view(350, 18)
   
    

    print("Your data:", input_data_class_1)
    print(input_data_class_1.shape)
    print("Output shape after self-attention:", output)
    print(output.shape)
    Sum_input_SA=output+input_data_class_1
    print("After summation:",Sum_input_SA)
    print(Sum_input_SA.shape)
    # Define the desired range (e.g., [0, 1] or [-1, 1])
    min_range = 0
    max_range = 1

    # Calculate the minimum and maximum values of the tensor
    min_val_class_1 = Sum_input_SA.min()
    max_val_class_1 = Sum_input_SA.max()

    # Apply min-max normalization
    normalized_input_SA = (Sum_input_SA - min_val_class_1) / (max_val_class_1 - min_val_class_1) * (max_range - min_range) + min_range

    # The 'normalized_tensor' now contains the values scaled to the specified range
    print("After Nomalization:",normalized_input_SA)
    print(normalized_input_SA.shape)
    
    
    #Convert this in Numpy Array
    matrix_as_numpy_class_1 = normalized_input_SA .detach().numpy()
    
    new_list_class_1 = []

    for j in range(0, 350):
        new_list_class_1.append(matrix_as_numpy_class_1[j])

    # Convert new_list to a NumPy array with shape (350, 18)
    new_list_class_1 = np.array(new_list_class_1)

    new_list_collection_class_1.append(new_list_class_1)

   

    
    
    
    
    intial_index__class_1=final_index_class_1
    final_index_class_1=final_index_class_1+350
result_array_class_1 = np.array(new_list_collection_class_1)






#Take only one Epox
intial_index__class_2=0
final_index_class_2 = 350

new_list_collection_class_2 = []


#For Class 2 Feature Extraction Using Self Attention
for i in range(0,80):
    # Example usage:
    input_dim_class_2 = 18
    seq_length_class_2 = 350

    Extracted_Epox_class_class_2 = from_class_2.iloc[intial_index__class_2: final_index_class_2, :].reset_index(drop=True)
    your_data_df_class_2 = Extracted_Epox_class_class_2
    # Convert the DataFrame to a PyTorch tensor
    input_data_class_2 = torch.tensor(your_data_df_class_2.values, dtype=torch.float32)
    # Initialize the self-attention module
    self_attention_class_2 = SelfAttention_function.SelfAttention(input_dim_class_2)
    
    
    
    # Apply self-attention to your data
    output_class_2 = self_attention_class_2(input_data_class_2.unsqueeze(1))
    # Reshape the output to the desired shape [350, 18]
    output_class_2 = output_class_2.view(350, 18)
   
    

    print("Your data:", input_data_class_2)
    print(input_data_class_2.shape)
    print("Output shape after self-attention:", output_class_2)
    print(output_class_2.shape)
    Sum_input_SA_class_2=output_class_2+input_data_class_2
    print("After summation:",Sum_input_SA_class_2)
    print(Sum_input_SA_class_2.shape)
    # Define the desired range (e.g., [0, 1] or [-1, 1])
    min_range = 0
    max_range = 1

    # Calculate the minimum and maximum values of the tensor
    min_val_class_2 = Sum_input_SA_class_2.min()
    max_val_class_2 = Sum_input_SA_class_2.max()

    # Apply min-max normalization
    normalized_input_SA_class_2 = (Sum_input_SA_class_2 - min_val_class_2) / (max_val_class_2 - min_val_class_2) * (max_range - min_range) + min_range

    # The 'normalized_tensor' now contains the values scaled to the specified range
    print("After Nomalization:",normalized_input_SA_class_2)
    print(normalized_input_SA_class_2.shape)
    
    
    #Convert this in Numpy Array
    matrix_as_numpy_class_2 = normalized_input_SA_class_2 .detach().numpy()
    
    new_list_class_2 = []

    for j in range(0, 350):
        new_list_class_2.append(matrix_as_numpy_class_2[j])

    # Convert new_list to a NumPy array with shape (350, 18)
    new_list_class_2 = np.array(new_list_class_2)

    new_list_collection_class_2.append(new_list_class_2)

   

    
    
    
    
    intial_index__class_2=final_index_class_2
    final_index_class_2=final_index_class_2+350
result_array_class_2 = np.array(new_list_collection_class_2)









# Concatenate the two arrays along the first axis
result_array_combined = np.concatenate((result_array_class_1, result_array_class_2), axis=0)


labels_class_1 = np.zeros(result_array_class_1.shape[0], dtype=int)
labels_class_2 = np.ones(result_array_class_2.shape[0], dtype=int)
labels_combined = np.concatenate((labels_class_1, labels_class_2), axis=0)



#split the data
X_train, X_test, y_train, y_test = train_test_split(result_array_combined, labels_combined, test_size=0.1, random_state=42)





# Specify the number of features to select for each channel
num_features_to_select = 1 # You can change this value to select more features


#pass the values for Mutual Information
#Feature_selection = Mutual_Information.calculate_mutual_information(result_array_combined,num_features_to_select)


# Split the list into class 1 and class 2
class_1_features_extraction = result_array_combined[:80]
class_2_features_extraction = result_array_combined[80:160]

# Reshape the lists into [80, 18] 2D arrays
class_1_features_EX = class_1_features_extraction.reshape(80,350, 18)
class_2_features_EX = class_2_features_extraction.reshape(80,350, 18)

# Stack the arrays to create a single [28000, 18] array for each class
class_1_features_2D_EX = class_1_features_EX.reshape(28000, 18)
class_2_features_2D_EX = class_2_features_EX.reshape(28000, 18)


# Save class 1 features to a CSV file
#np.savetxt("F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/class_1_features_Extraction.csv", class_1_features_2D_EX, delimiter=",")

# Save class 2 features to a CSV file
#np.savetxt("F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/class_2_features_Extraction.csv", class_2_features_2D_EX, delimiter=",")




