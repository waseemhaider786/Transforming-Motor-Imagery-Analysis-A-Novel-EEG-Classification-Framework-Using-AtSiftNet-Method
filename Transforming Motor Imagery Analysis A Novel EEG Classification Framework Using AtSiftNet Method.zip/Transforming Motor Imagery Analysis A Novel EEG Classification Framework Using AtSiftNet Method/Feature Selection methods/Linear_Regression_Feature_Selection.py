# -*- coding: utf-8 -*-
"""
Created on Wed Oct 11 19:49:38 2023

@author: wasee
"""
from sklearn.metrics import accuracy_score, confusion_matrix, roc_curve, roc_auc_score

# Define a function to plot ROC curve and calculate AUC
def plot_roc_auc(y_test, y_prob, model_name):
    fpr, tpr, thresholds = roc_curve(y_test, y_prob)
    auc = roc_auc_score(y_test, y_prob)

    plt.figure()
    plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'{model_name} (AUC = {auc:.2f})')
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title(f'ROC Curve - {model_name}')
    plt.legend(loc="lower right")
    plt.show()



import numpy as np
from sklearn.feature_selection import f_regression

# Load data from CSV files
features_from_class_1 = np.genfromtxt('I:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/class_1_features_Extraction.csv', delimiter=',')
features_from_class_2 = np.genfromtxt('I:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/class_2_features_Extraction.csv', delimiter=',')

# Number of top features to select from each column
top_k_features = 5

# Calculate feature importance using linear regression for each column of X
selected_features_values = []

# Take only one Epoch
initial_index_class_1 = 0
final_index_class_1 = 350

# For Class 1 Feature Extraction Using Linear Regression
for i in range(0, 80):
    X = features_from_class_1[initial_index_class_1: final_index_class_1, :]
    y = np.zeros(X.shape[0], dtype=int)
    for col in range(X.shape[1]):
        column_data = X[:, col]
        
        # Use Linear Regression to assess feature importance
        feature_importance = f_regression(column_data.reshape(-1, 1), y)
        
        # Sort features by importance and select the top-k
        top_features = np.argsort(feature_importance[0])[::-1][:top_k_features]
        
        # Extract the values of the selected features
        selected_feature_values = column_data[top_features]
        selected_features_values.extend(selected_feature_values)

    # Print the values of the selected features
    print("Selected feature values:", selected_features_values)
    selected_features_array = np.array(selected_features_values).reshape(1, -1)
    initial_index_class_1 = final_index_class_1
    final_index_class_1 = final_index_class_1 + 350

# Define the dimensions of the 2D array
rows = 80
columns = 18

# Reshape the original array into a 2D array with the specified dimensions
Final_selected_features_class_1 = selected_features_array.reshape(rows, columns)

# You can repeat a similar process for class 2 if needed.

# For class 2 (Class 2 Feature Extraction Using Linear Regression)
selected_features_values = []
initial_index_class_2 = 0
final_index_class_2 = 350

for i in range(0, 80):
    W = features_from_class_2[initial_index_class_2: final_index_class_2, :]
    s = np.ones(W.shape[0], dtype=int)
    for col in range(W.shape[1]):
        column_data = W[:, col]

        # Use Linear Regression to assess feature importance
        feature_importance = f_regression(column_data.reshape(-1, 1), s)

        # Sort features by importance and select the top-k
        top_features = np.argsort(feature_importance[0])[::-1][:top_k_features]

        # Extract the values of the selected features
        selected_feature_values = column_data[top_features]
        selected_features_values.extend(selected_feature_values)

    # Print the values of the selected features
    print("Selected feature values:", selected_features_values)
    selected_features_array = np.array(selected_features_values).reshape(1, -1)
    initial_index_class_2 = final_index_class_2
    final_index_class_2 = final_index_class_2 + 350

# Define the dimensions of the 2D array
Final_selected_features_class_2 = selected_features_array.reshape(rows, columns)






import numpy as np
from sklearn import svm
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix



# Load data from CSV files
features_from_class_1 = Final_selected_features_class_1
features_from_class_2 = Final_selected_features_class_2



import matplotlib.pyplot as plt

plt.scatter(features_from_class_1[:, 0], features_from_class_1[:, 1], marker='o', label='Class 1')
plt.scatter(features_from_class_2[:, 0], features_from_class_2[:, 1], marker='x', label='Class 2')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.title('Cluster Visualization')
plt.legend(loc='best')


# Feature extraction
feature_matrix = np.vstack((features_from_class_1, features_from_class_2))
output_vector = np.hstack((np.ones(features_from_class_1.shape[0]), -1 * np.ones(features_from_class_2.shape[0])))
#print(feature_matrix)


# Data normalization
scaler = StandardScaler()
normalized_feature_matrix = scaler.fit_transform(feature_matrix)


# Split data into training and testing sets (70-30 split)
X_train_svm, X_test_svm, y_train_svm, y_test_svm = train_test_split(
    normalized_feature_matrix, output_vector, test_size=0.2, random_state=42
)



# Train the SVM classifier
SVM_model = svm.SVC(kernel='rbf', C=1, gamma='scale')
SVM_model.fit(X_train_svm, y_train_svm)


# Test the SVM classifier
predicted_labels = SVM_model.predict(X_test_svm)





# Calculate the accuracy
accuracy = accuracy_score(y_test_svm, predicted_labels) * 100




# Calculate the confusion matrix
conf_matrix = confusion_matrix(y_test_svm, predicted_labels)
print(conf_matrix)




# Calculate sensitivity (recall) and specificity
TP = conf_matrix[0, 0]
FN = conf_matrix[0, 1]
FP = conf_matrix[1, 0]
TN = conf_matrix[1, 1]




sensitivity = (TP / (TP + FN)) * 100
specificity = (TN / (TN + FP)) * 100




# Display the results
print(f'Accuracy of Support Vector Machine (SVM) is: {accuracy:.2f}%')
print(f'Sensitivity of Support Vector Machine (SVM) is: {sensitivity:.2f}%')
print(f'Specificity of Support Vector Machine (SVM) is: {specificity:.2f}%')


#########################################
########################################
##############################################################################

import numpy as np
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix



# Load data from CSV files
features_from_class_1 = Final_selected_features_class_1
features_from_class_2 = Final_selected_features_class_2







# Feature extraction
feature_matrix = np.vstack((features_from_class_1, features_from_class_2))
output_vector = np.hstack((np.ones(features_from_class_1.shape[0]), -1 * np.ones(features_from_class_2.shape[0])))




# Data normalization
scaler = StandardScaler()
normalized_feature_matrix = scaler.fit_transform(feature_matrix)




# Split data into training and testing sets (70-30 split)
X_train_lda, X_test_lda, y_train_lda, y_test_lda = train_test_split(
    normalized_feature_matrix, output_vector, test_size=0.2, random_state=42
)




# Train the LDA classifier
lda_model = LDA()
lda_model.fit(X_train_lda, y_train_lda)









# Test the LDA classifier
predicted_labels = lda_model.predict(X_test_lda)



# Calculate the accuracy
accuracy = accuracy_score(y_test_lda, predicted_labels) * 100




# Calculate the confusion matrix
conf_matrix = confusion_matrix(y_test_lda, predicted_labels)
print(conf_matrix)


# Calculate sensitivity (recall) and specificity
TP = conf_matrix[0, 0]
FN = conf_matrix[0, 1]
FP = conf_matrix[1, 0]
TN = conf_matrix[1, 1]

sensitivity = TP / (TP + FN) * 100
specificity = TN / (TN + FP) * 100



# Display the results
print(f'Accuracy of Linear Discriminant Analysis (LDA) is: {accuracy:.2f}%')
print(f'Sensitivity of Linear Discriminant Analysis (LDA) is: {sensitivity:.2f}%')
print(f'Specificity of Linear Discriminant Analysis (LDA) is: {specificity:.2f}%')



#############################################################################################
############################################################################################
#############################################################################################


# -*- coding: utf-8 -*-
"""
Created on Fri Oct  6 17:55:00 2023

@author: wasee
"""
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, confusion_matrix




# Load data from CSV files
features_from_class_1 = Final_selected_features_class_1
features_from_class_2 = Final_selected_features_class_2





X = np.vstack((features_from_class_1, features_from_class_2))
y = np.hstack((np.ones(features_from_class_1.shape[0]), -1 * np.ones(features_from_class_2.shape[0])))



X_train_KNN, X_test_KNN, y_train_KNN, y_test_KNN = train_test_split(X, y, test_size=0.2, random_state=42)



# Create a KNN classifier with a specified number of neighbors
k = 2
knn_classifier = KNeighborsClassifier(n_neighbors=k)



# Fit the classifier to the training data
knn_classifier.fit(X_train_KNN, y_train_KNN)




# Make predictions on the test data
y_pred = knn_classifier.predict(X_test_KNN)





# Calculate accuracy and display classification report
accuracy = accuracy_score(y_test_KNN, y_pred)
# Calculate confusion matrix to compute sensitivity and specificity
conf_matrix = confusion_matrix(y_test_KNN, y_pred)
# Calculate sensitivity (recall) and specificity
true_positives = conf_matrix[1, 1]
false_negatives = conf_matrix[1, 0]
true_negatives = conf_matrix[0, 0]
false_positives = conf_matrix[0, 1]
sensitivity = true_positives / (true_positives + false_negatives)
specificity = true_negatives / (true_negatives + false_positives)





print(f"Accuracy of KNN: {accuracy*100}%")
print(f"Sensitivity of KNN: {sensitivity*100:.2f}%")
print(f"Specificity of KNN: {specificity*100:.2f}%")



# =============================================================================
# # Save class 1 features to a CSV file
np.savetxt("I:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_1_features_Selection_LR.csv", Final_selected_features_class_1, delimiter=",")
# 
# # Save class 2 features to a CSV file
np.savetxt("I:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_2_features_Selection_LR.csv", Final_selected_features_class_2, delimiter=",")
# 
# 
# =============================================================================


############################################################################
############################################################################
############################################################################

import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, roc_curve, roc_auc_score




# Load data from CSV files
features_from_class_1 = Final_selected_features_class_1
features_from_class_2 = Final_selected_features_class_2

X = np.vstack((features_from_class_1, features_from_class_2))
y = np.hstack((np.ones(features_from_class_1.shape[0]), -1 * np.ones(features_from_class_2.shape[0])))

X_train_RF, X_test_RF, y_train_RF, y_test_RF = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a Random Forest classifier
random_forest_classifier = RandomForestClassifier(n_estimators=100, random_state=42)

# Fit the classifier to the training data
random_forest_classifier.fit(X_train_RF, y_train_RF)



# Make predictions on the test data
y_pred = random_forest_classifier.predict(X_test_RF)

# Calculate accuracy and display classification report
accuracy = accuracy_score(y_test_RF, y_pred)

# Calculate confusion matrix to compute sensitivity and specificity
conf_matrix = confusion_matrix(y_test_RF, y_pred)

# Calculate sensitivity (recall) and specificity
true_positives = conf_matrix[1, 1]
false_negatives = conf_matrix[1, 0]
true_negatives = conf_matrix[0, 0]
false_positives = conf_matrix[0, 1]
sensitivity = true_positives / (true_positives + false_negatives)
specificity = true_negatives / (true_negatives + false_positives)

print(f"Accuracy of Random Forest: {accuracy * 100}%")
print(f"Sensitivity of Random Forest: {sensitivity * 100:.2f}%")
print(f"Specificity of Random Forest: {specificity * 100:.2f}%")





#########################################################################
#######################################################################
########################################################################




import numpy as np
from sklearn.model_selection import train_test_split
import xgboost as xgb
from sklearn.metrics import accuracy_score, confusion_matrix

# Load data from CSV files
features_from_class_1 = Final_selected_features_class_1
features_from_class_2 = Final_selected_features_class_2

X = np.vstack((features_from_class_1, features_from_class_2))
y = np.hstack((np.zeros(features_from_class_1.shape[0]), np.ones(features_from_class_2.shape[0])))

X_train_XG, X_test_XG, y_train_XG, y_test_XG = train_test_split(X, y, test_size=0.2, random_state=42)

# Create an XGBoost classifier
xgb_classifier = xgb.XGBClassifier()

# Fit the classifier to the training data
xgb_classifier.fit(X_train_XG, y_train_XG)

# Make predictions on the test data
y_pred = xgb_classifier.predict(X_test_XG)

# Calculate accuracy and display classification report
accuracy = accuracy_score(y_test_XG, y_pred)

# Calculate confusion matrix to compute sensitivity and specificity
conf_matrix = confusion_matrix(y_test_XG, y_pred)

# Calculate sensitivity (recall) and specificity
true_positives = conf_matrix[1, 1]
false_negatives = conf_matrix[1, 0]
true_negatives = conf_matrix[0, 0]
false_positives = conf_matrix[0, 1]
sensitivity = true_positives / (true_positives + false_negatives)
specificity = true_negatives / (true_negatives + false_positives)

print(f"Accuracy of XGBoost: {accuracy * 100}%")
print(f"Sensitivity of XGBoost: {sensitivity * 100:.2f}%")
print(f"Specificity of XGBoost: {specificity * 100:.2f}%")







import plot_roc_auc_function
y_scores_svm = SVM_model.decision_function(X_test_svm)
y_prob_lda = lda_model.predict_proba(X_test_lda)[:,1]
y_prob_rf = random_forest_classifier.predict_proba(X_test_RF)[:,1]
y_prob_knn = knn_classifier.predict_proba(X_test_KNN)[:,1]
y_prob_xgb = xgb_classifier.predict_proba(X_test_XG)[:,1]





plt.figure()
plot_roc_auc_function.plot_roc_auc(y_test_svm, y_scores_svm, 'SVM')
plot_roc_auc_function.plot_roc_auc(y_test_lda, y_prob_lda, 'LDA')
plot_roc_auc_function.plot_roc_auc(y_test_RF, y_prob_rf, 'Random Forest')
plot_roc_auc_function.plot_roc_auc(y_test_KNN, y_prob_knn, 'KNN')
plot_roc_auc_function.plot_roc_auc(y_test_XG, y_prob_xgb, 'XGBoost')

# Plot the random (chance) line
plt.plot([0, 1], [0, 1], linestyle='--', color='gray')

# Set labels and title
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve - subject 1')

# Add a legend
plt.legend(loc='lower right')

# Show the plot
plt.show()