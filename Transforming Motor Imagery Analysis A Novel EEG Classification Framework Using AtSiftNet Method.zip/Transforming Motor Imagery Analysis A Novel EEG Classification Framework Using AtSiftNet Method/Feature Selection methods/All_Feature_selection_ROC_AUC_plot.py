# -*- coding: utf-8 -*-
"""
Created on Wed Nov  8 11:27:15 2023

@author: waseem haider
"""

import numpy as np
from sklearn import svm
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix



# Load data from CSV files
features_from_class_1_LR = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_1_features_Selection_LR.csv', delimiter=',')
features_from_class_2_LR = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_2_features_Selection_LR.csv', delimiter=',')


# Load data from CSV files
features_from_class_1_RF = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_1_features_Selection_ReliefF.csv', delimiter=',')
features_from_class_2_RF = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_2_features_Selection_ReliefF.csv', delimiter=',')

# Load data from CSV files
features_from_class_1_MI = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_1_features_Selection_MI.csv', delimiter=',')
features_from_class_2_MI = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_2_features_Selection_MI.csv', delimiter=',')



# Load data from CSV files
features_from_class_1_C = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_1_features_Selection_Correlation.csv', delimiter=',')
features_from_class_2_C = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_2_features_Selection_Correlation.csv', delimiter=',')






# Load data from CSV files
features_from_class_1_RFE = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_1_features_Selection_RFE.csv', delimiter=',')
features_from_class_2_RFE = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_2_features_Selection_RFE.csv', delimiter=',')




# Load data from CSV files
features_from_class_1_PCA = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_1_features_Selection_PCA.csv', delimiter=',')
features_from_class_2_PCA = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_2_features_Selection_PCA.csv', delimiter=',')




# Load data from CSV files
features_from_class_1_NCA = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_1_features_Selection_NCA.csv', delimiter=',')
features_from_class_2_NCA = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_2_features_Selection_NCA.csv', delimiter=',')



# Load data from CSV files
features_from_class_1_ICA = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_1_features_Selection_ICA.csv', delimiter=',')
features_from_class_2_ICA = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_2_features_Selection_ICA.csv', delimiter=',')






import matplotlib.pyplot as plt




# Feature extraction
feature_matrix_LR = np.vstack((features_from_class_1_LR , features_from_class_2_LR ))
output_vector_LR = np.hstack((np.ones(features_from_class_1_LR .shape[0]), -1 * np.ones(features_from_class_1_LR .shape[0])))
#print(feature_matrix)


# Data normalization
scaler = StandardScaler()
normalized_feature_matrix_LR = scaler.fit_transform(feature_matrix_LR)


# Split data into training and testing sets (70-30 split)
X_train_LR, X_test_LR, y_train_LR, y_test_LR = train_test_split(
    normalized_feature_matrix_LR, output_vector_LR, test_size=0.2, random_state=42
)



# Train the SVM classifier
SVM_model_LR = svm.SVC(kernel='rbf', C=1, gamma='scale')
SVM_model_LR.fit(X_train_LR, y_train_LR)






# Feature extraction
feature_matrix_RF = np.vstack((features_from_class_1_RF , features_from_class_2_RF ))
output_vector_RF = np.hstack((np.ones(features_from_class_1_RF .shape[0]), -1 * np.ones(features_from_class_1_RF .shape[0])))
#print(feature_matrix)


# Data normalization
scaler = StandardScaler()
normalized_feature_matrix_RF = scaler.fit_transform(feature_matrix_RF)


# Split data into training and testing sets (70-30 split)
X_train_RF, X_test_RF, y_train_RF, y_test_RF = train_test_split(
    normalized_feature_matrix_RF, output_vector_RF, test_size=0.2, random_state=42
)



# Train the SVM classifier
SVM_model_RF = svm.SVC(kernel='rbf', C=1, gamma='scale')
SVM_model_RF.fit(X_train_RF, y_train_RF)





# Feature extraction
feature_matrix_C = np.vstack((features_from_class_1_C , features_from_class_2_C ))
output_vector_C = np.hstack((np.ones(features_from_class_1_C .shape[0]), -1 * np.ones(features_from_class_1_C .shape[0])))
#print(feature_matrix)


# Data normalization
scaler = StandardScaler()
normalized_feature_matrix_C = scaler.fit_transform(feature_matrix_C)


# Split data into training and testing sets (70-30 split)
X_train_C, X_test_C, y_train_C, y_test_C = train_test_split(
    normalized_feature_matrix_C, output_vector_C, test_size=0.2, random_state=42
)



# Train the SVM classifier
SVM_model_C = svm.SVC(kernel='rbf', C=1, gamma='scale')
SVM_model_C.fit(X_train_C, y_train_C)









# Feature extraction
feature_matrix_MI = np.vstack((features_from_class_1_MI , features_from_class_2_MI ))
output_vector_MI = np.hstack((np.ones(features_from_class_1_MI .shape[0]), -1 * np.ones(features_from_class_1_MI .shape[0])))
#print(feature_matrix)


# Data normalization
scaler = StandardScaler()
normalized_feature_matrix_MI = scaler.fit_transform(feature_matrix_MI)


# Split data into training and testing sets (70-30 split)
X_train_MI, X_test_MI, y_train_MI, y_test_MI = train_test_split(
    normalized_feature_matrix_MI, output_vector_MI, test_size=0.2, random_state=42
)



# Train the SVM classifier
SVM_model_MI = svm.SVC(kernel='rbf', C=1, gamma='scale')
SVM_model_MI.fit(X_train_MI, y_train_MI)










# Feature extraction
feature_matrix_RFE = np.vstack((features_from_class_1_RFE , features_from_class_2_RFE ))
output_vector_RFE = np.hstack((np.ones(features_from_class_1_RFE .shape[0]), -1 * np.ones(features_from_class_1_RFE .shape[0])))
#print(feature_matrix)


# Data normalization
scaler = StandardScaler()
normalized_feature_matrix_RFE = scaler.fit_transform(feature_matrix_RFE)


# Split data into training and testing sets (70-30 split)
X_train_RFE, X_test_RFE, y_train_RFE, y_test_RFE = train_test_split(
    normalized_feature_matrix_RFE, output_vector_RFE, test_size=0.2, random_state=42
)



# Train the SVM classifier
SVM_model_RFE = svm.SVC(kernel='rbf', C=1, gamma='scale')
SVM_model_RFE.fit(X_train_RFE, y_train_RFE)







# Feature extraction
feature_matrix_PCA = np.vstack((features_from_class_1_PCA , features_from_class_2_PCA ))
output_vector_PCA = np.hstack((np.ones(features_from_class_1_PCA .shape[0]), -1 * np.ones(features_from_class_1_PCA .shape[0])))
#print(feature_matrix)


# Data normalization
scaler = StandardScaler()
normalized_feature_matrix_PCA= scaler.fit_transform(feature_matrix_PCA)


# Split data into training and testing sets (70-30 split)
X_train_PCA, X_test_PCA, y_train_PCA, y_test_PCA = train_test_split(
    normalized_feature_matrix_PCA, output_vector_PCA, test_size=0.2, random_state=42
)



# Train the SVM classifier
SVM_model_PCA = svm.SVC(kernel='rbf', C=1, gamma='scale')
SVM_model_PCA.fit(X_train_PCA, y_train_PCA)







# Feature extraction
feature_matrix_NCA = np.vstack((features_from_class_1_NCA , features_from_class_2_NCA ))
output_vector_NCA = np.hstack((np.ones(features_from_class_1_NCA .shape[0]), -1 * np.ones(features_from_class_1_NCA .shape[0])))
#print(feature_matrix)


# Data normalization
scaler = StandardScaler()
normalized_feature_matrix_NCA= scaler.fit_transform(feature_matrix_NCA)


# Split data into training and testing sets (70-30 split)
X_train_NCA, X_test_NCA, y_train_NCA, y_test_NCA = train_test_split(
    normalized_feature_matrix_NCA, output_vector_NCA, test_size=0.2, random_state=42
)



# Train the SVM classifier
SVM_model_NCA = svm.SVC(kernel='rbf', C=1, gamma='scale')
SVM_model_NCA.fit(X_train_NCA, y_train_NCA)









# Feature extraction
feature_matrix_ICA = np.vstack((features_from_class_1_ICA , features_from_class_2_ICA ))
output_vector_ICA = np.hstack((np.ones(features_from_class_1_ICA .shape[0]), -1 * np.ones(features_from_class_1_ICA .shape[0])))
#print(feature_matrix)


# Data normalization
scaler = StandardScaler()
normalized_feature_matrix_ICA= scaler.fit_transform(feature_matrix_ICA)


# Split data into training and testing sets (70-30 split)
X_train_ICA, X_test_ICA, y_train_ICA, y_test_ICA = train_test_split(
    normalized_feature_matrix_ICA, output_vector_ICA, test_size=0.2, random_state=42
)



# Train the SVM classifier
SVM_model_ICA = svm.SVC(kernel='rbf', C=1, gamma='scale')
SVM_model_ICA.fit(X_train_ICA, y_train_ICA)










import plot_roc_auc_function
y_scores_LR = SVM_model_LR.decision_function(X_test_LR)
y_scores_RF = SVM_model_RF.decision_function(X_test_RF)
y_scores_MI = SVM_model_MI.decision_function(X_test_MI)
y_scores_C = SVM_model_C.decision_function(X_test_C)
y_scores_RFE = SVM_model_RFE.decision_function(X_test_RFE)
y_scores_PCA = SVM_model_PCA.decision_function(X_test_PCA)
y_scores_NCA = SVM_model_NCA.decision_function(X_test_NCA)
y_scores_ICA = SVM_model_ICA.decision_function(X_test_ICA)




plt.figure()
plot_roc_auc_function.plot_roc_auc(y_test_LR, y_scores_LR, 'Linear Regression')
plot_roc_auc_function.plot_roc_auc(y_test_RF, y_scores_RF, 'ReliefF')
plot_roc_auc_function.plot_roc_auc(y_test_MI, y_scores_MI, 'Mutual Information')
plot_roc_auc_function.plot_roc_auc(y_test_C, y_scores_C, 'Correlation FS')
plot_roc_auc_function.plot_roc_auc(y_test_RFE, y_scores_RFE, 'RFE')
plot_roc_auc_function.plot_roc_auc(y_test_PCA, y_scores_PCA, 'PCA')
plot_roc_auc_function.plot_roc_auc(y_test_NCA, y_scores_NCA, 'NCA')
plot_roc_auc_function.plot_roc_auc(y_test_ICA, y_scores_ICA, 'ICA')







# Plot the random (chance) line
plt.plot([0, 1], [0, 1], linestyle='--', color='black')

# Set labels and title
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve - subject 5')

# Add a legend
plt.legend(loc='best',fontsize=7.5)

# Show the plot
plt.show()