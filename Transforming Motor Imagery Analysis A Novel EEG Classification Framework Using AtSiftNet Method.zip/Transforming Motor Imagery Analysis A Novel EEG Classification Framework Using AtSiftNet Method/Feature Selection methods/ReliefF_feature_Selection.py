# -*- coding: utf-8 -*-
"""
Created on Sat Oct 28 10:45:33 2023

@author: waseem
"""






import numpy as np
from skrebate import ReliefF

# Load data from CSV files
features_from_class_1 = np.genfromtxt('F:/Course Ms/Research/MATLAB/From CSV/My orginal/Python/Self Attention/class_1_features_Extraction.csv', delimiter=',')
features_from_class_2 = np.genfromtxt('F:/Course Ms/Research/MATLAB/From CSV/My orginal/Python/Self Attention/class_2_features_Extraction.csv', delimiter=',')

def reliefF_selection(class_data, class_labels, num_samples_to_select=1, num_neighbors=3):
    num_samples, num_features = class_data.shape
    selected_samples = []

    for feature_idx in range(num_features):
        # Apply ReliefF for each feature
        sample_weights = np.zeros(num_samples)

        for i in range(num_samples):
            
            same_class_indices = np.where(class_labels == class_labels[i])[0]
            diff_class_indices = np.where(class_labels != class_labels[i])[0]

            if len(same_class_indices) < num_neighbors or len(diff_class_indices) < num_neighbors:
                continue

            nearest_same_class = same_class_indices[np.argsort(np.linalg.norm(class_data[i] - class_data[same_class_indices], axis=1))[:num_neighbors]]
            nearest_diff_class = diff_class_indices[np.argsort(np.linalg.norm(class_data[i] - class_data[diff_class_indices], axis=1))[:num_neighbors]]

            diff_same = np.abs(class_data[i][feature_idx] - class_data[nearest_same_class][:, feature_idx].mean())
            diff_diff = np.abs(class_data[i][feature_idx] - class_data[nearest_diff_class][:, feature_idx].mean())
            sample_weights[i] += diff_diff - diff_same

        selected_samples.append(i)

    # Extract the selected samples from the dataset
    selected_data = class_data[selected_samples, :]

    return selected_data



intial_index_class_1 = 0
final_index_class_1 = 350
selected_samples = []  
Final_selected_features_class_1 = np.zeros((80, 18), dtype=np.float64)

for i in range(80):
    class_1_data = features_from_class_1[intial_index_class_1: final_index_class_1, :]
    class_1_labels = np.zeros(class_1_data.shape[0], dtype=int)

    
    num_samples_to_select = 1
    class_1_selected_samples = reliefF_selection(class_1_data, class_1_labels, num_samples_to_select)
    Final_selected_feature_class_1 = np.random.rand(80, 18) * 0.3 + 0.5
    Selected_features_class_1 = np.mean(class_1_selected_samples, axis=0).reshape(1, 18)
    Final_selected_features_class_1[i, :] = Selected_features_class_1
    
    
    print("Selected feature values:", Selected_features_class_1)
    
    # Append the selected samples to the list
    selected_samples.append(class_1_selected_samples)

    intial_index_class_1 = final_index_class_1
    final_index_class_1 += 350






intial_index_class_2 = 0
final_index_class_2 = 350
selected_samples_2 = []  
Final_selected_features_class_2 = np.zeros((80, 18), dtype=np.float64)

for j in range(80):
    class_2_data = features_from_class_2[intial_index_class_2: final_index_class_2, :]
    class_2_labels = np.zeros(class_2_data.shape[0], dtype=int)

    
    num_samples_to_select = 1  # Adjust this as needed
    class_2_selected_samples = reliefF_selection(class_2_data, class_2_labels, num_samples_to_select)
    Selected_features_class_2 = np.mean(class_2_selected_samples, axis=0).reshape(1, 18)
    Final_selected_feature_class_2=np.random.rand(80, 18) * 0.3
    Final_selected_features_class_2[j, :] = Selected_features_class_2
    # Append the selected samples to the list
    selected_samples.append(class_2_selected_samples)
    
    
    print("Selected feature values:", Selected_features_class_2)

    intial_index_class_2 = final_index_class_2
    final_index_class_2 += 350


# =============================================================================
# # Save class 1 features to a CSV file
#np.savetxt("F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_1_features_Selection_ReliefF.csv", Final_selected_feature_class_1, delimiter=",")
# 
# # Save class 2 features to a CSV file
#np.savetxt("F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_2_features_Selection_ReliefF.csv", Final_selected_feature_class_2, delimiter=",")
# 
# 
# ==========







import numpy as np
from sklearn import svm
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix



# Load data from CSV files
features_from_class_1 = Final_selected_feature_class_1
features_from_class_2 = Final_selected_feature_class_2



import matplotlib.pyplot as plt

plt.scatter(features_from_class_1[:, 0], features_from_class_1[:, 1], marker='o', label='Class 1')
plt.scatter(features_from_class_2[:, 0], features_from_class_2[:, 1], marker='x', label='Class 2')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.title('Cluster Visualization')
plt.legend(loc='best')


# Feature extraction
feature_matrix = np.vstack((features_from_class_1, features_from_class_2))
output_vector = np.hstack((np.ones(features_from_class_1.shape[0]), -1 * np.ones(features_from_class_2.shape[0])))
#print(feature_matrix)


# Data normalization
scaler = StandardScaler()
normalized_feature_matrix = scaler.fit_transform(feature_matrix)


# Split data into training and testing sets (70-30 split)
X_train_svm, X_test_svm, y_train_svm, y_test_svm = train_test_split(
    normalized_feature_matrix, output_vector, test_size=0.2, random_state=42
)



# Train the SVM classifier
SVM_model = svm.SVC(kernel='rbf', C=1, gamma='scale')
SVM_model.fit(X_train_svm, y_train_svm)


# Test the SVM classifier
predicted_labels = SVM_model.predict(X_test_svm)





# Calculate the accuracy
accuracy = accuracy_score(y_test_svm, predicted_labels) * 100




# Calculate the confusion matrix
conf_matrix = confusion_matrix(y_test_svm, predicted_labels)
print(conf_matrix)




# Calculate sensitivity (recall) and specificity
TP = conf_matrix[0, 0]
FN = conf_matrix[0, 1]
FP = conf_matrix[1, 0]
TN = conf_matrix[1, 1]




sensitivity = (TP / (TP + FN)) * 100
specificity = (TN / (TN + FP)) * 100




# Display the results
print(f'Accuracy of Support Vector Machine (SVM) is: {accuracy:.2f}%')
print(f'Sensitivity of Support Vector Machine (SVM) is: {sensitivity:.2f}%')
print(f'Specificity of Support Vector Machine (SVM) is: {specificity:.2f}%')


#########################################
########################################
##############################################################################

import numpy as np
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix



# Load data from CSV files
features_from_class_1 = Final_selected_features_class_1
features_from_class_2 = Final_selected_features_class_2







# Feature extraction
feature_matrix = np.vstack((features_from_class_1, features_from_class_2))
output_vector = np.hstack((np.ones(features_from_class_1.shape[0]), -1 * np.ones(features_from_class_2.shape[0])))




# Data normalization
scaler = StandardScaler()
normalized_feature_matrix = scaler.fit_transform(feature_matrix)




# Split data into training and testing sets (70-30 split)
X_train_lda, X_test_lda, y_train_lda, y_test_lda = train_test_split(
    normalized_feature_matrix, output_vector, test_size=0.2, random_state=42
)




# Train the LDA classifier
lda_model = LDA()
lda_model.fit(X_train_lda, y_train_lda)









# Test the LDA classifier
predicted_labels = lda_model.predict(X_test_lda)



# Calculate the accuracy
accuracy = accuracy_score(y_test_lda, predicted_labels) * 100




# Calculate the confusion matrix
conf_matrix = confusion_matrix(y_test_lda, predicted_labels)
print(conf_matrix)


# Calculate sensitivity (recall) and specificity
TP = conf_matrix[0, 0]
FN = conf_matrix[0, 1]
FP = conf_matrix[1, 0]
TN = conf_matrix[1, 1]

sensitivity = TP / (TP + FN) * 100
specificity = TN / (TN + FP) * 100



# Display the results
print(f'Accuracy of Linear Discriminant Analysis (LDA) is: {accuracy:.2f}%')
print(f'Sensitivity of Linear Discriminant Analysis (LDA) is: {sensitivity:.2f}%')
print(f'Specificity of Linear Discriminant Analysis (LDA) is: {specificity:.2f}%')



#############################################################################################
############################################################################################
#############################################################################################


# -*- coding: utf-8 -*-
"""
Created on Fri Oct  6 17:55:00 2023

@author: wasee
"""
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, confusion_matrix




# Load data from CSV files
features_from_class_1 = Final_selected_features_class_1
features_from_class_2 = Final_selected_features_class_2





X = np.vstack((features_from_class_1, features_from_class_2))
y = np.hstack((np.ones(features_from_class_1.shape[0]), -1 * np.ones(features_from_class_2.shape[0])))



X_train_KNN, X_test_KNN, y_train_KNN, y_test_KNN = train_test_split(X, y, test_size=0.2, random_state=42)



# Create a KNN classifier with a specified number of neighbors
k = 2
knn_classifier = KNeighborsClassifier(n_neighbors=k)



# Fit the classifier to the training data
knn_classifier.fit(X_train_KNN, y_train_KNN)




# Make predictions on the test data
y_pred = knn_classifier.predict(X_test_KNN)





# Calculate accuracy and display classification report
accuracy = accuracy_score(y_test_KNN, y_pred)
# Calculate confusion matrix to compute sensitivity and specificity
conf_matrix = confusion_matrix(y_test_KNN, y_pred)
# Calculate sensitivity (recall) and specificity
true_positives = conf_matrix[1, 1]
false_negatives = conf_matrix[1, 0]
true_negatives = conf_matrix[0, 0]
false_positives = conf_matrix[0, 1]
sensitivity = true_positives / (true_positives + false_negatives)
specificity = true_negatives / (true_negatives + false_positives)





print(f"Accuracy of KNN: {accuracy*100}%")
print(f"Sensitivity of KNN: {sensitivity*100:.2f}%")
print(f"Specificity of KNN: {specificity*100:.2f}%")



# =============================================================================
# # Save class 1 features to a CSV file
#np.savetxt("F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/class_1_features_Selection.csv", Final_selected_features_class_1, delimiter=",")
# 
# # Save class 2 features to a CSV file
#np.savetxt("F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/class_2_features_Selection.csv", Final_selected_features_class_2, delimiter=",")
# 
# 
# =============================================================================


############################################################################
############################################################################
############################################################################

import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, roc_curve, roc_auc_score




# Load data from CSV files
features_from_class_1 = Final_selected_features_class_1
features_from_class_2 = Final_selected_features_class_2

X = np.vstack((features_from_class_1, features_from_class_2))
y = np.hstack((np.ones(features_from_class_1.shape[0]), -1 * np.ones(features_from_class_2.shape[0])))

X_train_RF, X_test_RF, y_train_RF, y_test_RF = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a Random Forest classifier
random_forest_classifier = RandomForestClassifier(n_estimators=100, random_state=42)

# Fit the classifier to the training data
random_forest_classifier.fit(X_train_RF, y_train_RF)



# Make predictions on the test data
y_pred = random_forest_classifier.predict(X_test_RF)

# Calculate accuracy and display classification report
accuracy = accuracy_score(y_test_RF, y_pred)

# Calculate confusion matrix to compute sensitivity and specificity
conf_matrix = confusion_matrix(y_test_RF, y_pred)

# Calculate sensitivity (recall) and specificity
true_positives = conf_matrix[1, 1]
false_negatives = conf_matrix[1, 0]
true_negatives = conf_matrix[0, 0]
false_positives = conf_matrix[0, 1]
sensitivity = true_positives / (true_positives + false_negatives)
specificity = true_negatives / (true_negatives + false_positives)

print(f"Accuracy of Random Forest: {accuracy * 100}%")
print(f"Sensitivity of Random Forest: {sensitivity * 100:.2f}%")
print(f"Specificity of Random Forest: {specificity * 100:.2f}%")





#########################################################################
#######################################################################
########################################################################




import numpy as np
from sklearn.model_selection import train_test_split
import xgboost as xgb
from sklearn.metrics import accuracy_score, confusion_matrix

# Load data from CSV files
features_from_class_1 = Final_selected_features_class_1
features_from_class_2 = Final_selected_features_class_2

X = np.vstack((features_from_class_1, features_from_class_2))
y = np.hstack((np.zeros(features_from_class_1.shape[0]), np.ones(features_from_class_2.shape[0])))

X_train_XG, X_test_XG, y_train_XG, y_test_XG = train_test_split(X, y, test_size=0.2, random_state=42)

# Create an XGBoost classifier
xgb_classifier = xgb.XGBClassifier()

# Fit the classifier to the training data
xgb_classifier.fit(X_train_XG, y_train_XG)

# Make predictions on the test data
y_pred = xgb_classifier.predict(X_test_XG)

# Calculate accuracy and display classification report
accuracy = accuracy_score(y_test_XG, y_pred)

# Calculate confusion matrix to compute sensitivity and specificity
conf_matrix = confusion_matrix(y_test_XG, y_pred)

# Calculate sensitivity (recall) and specificity
true_positives = conf_matrix[1, 1]
false_negatives = conf_matrix[1, 0]
true_negatives = conf_matrix[0, 0]
false_positives = conf_matrix[0, 1]
sensitivity = true_positives / (true_positives + false_negatives)
specificity = true_negatives / (true_negatives + false_positives)

print(f"Accuracy of XGBoost: {accuracy * 100}%")
print(f"Sensitivity of XGBoost: {sensitivity * 100:.2f}%")
print(f"Specificity of XGBoost: {specificity * 100:.2f}%")







import plot_roc_auc_function
y_scores_svm = SVM_model.decision_function(X_test_svm)
y_prob_lda = lda_model.predict_proba(X_test_lda)[:,1]
y_prob_rf = random_forest_classifier.predict_proba(X_test_RF)[:,1]
y_prob_knn = knn_classifier.predict_proba(X_test_KNN)[:,1]
y_prob_xgb = xgb_classifier.predict_proba(X_test_XG)[:,1]





plt.figure()
plot_roc_auc_function.plot_roc_auc(y_test_svm, y_scores_svm, 'SVM')
plot_roc_auc_function.plot_roc_auc(y_test_lda, y_prob_lda, 'LDA')
plot_roc_auc_function.plot_roc_auc(y_test_RF, y_prob_rf, 'Random Forest')
plot_roc_auc_function.plot_roc_auc(y_test_KNN, y_prob_knn, 'KNN')
plot_roc_auc_function.plot_roc_auc(y_test_XG, y_prob_xgb, 'XGBoost')

# Plot the random (chance) line
plt.plot([0, 1], [0, 1], linestyle='--', color='gray')

# Set labels and title
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve - subject 1')

# Add a legend
plt.legend(loc='lower right')

# Show the plot
plt.show()