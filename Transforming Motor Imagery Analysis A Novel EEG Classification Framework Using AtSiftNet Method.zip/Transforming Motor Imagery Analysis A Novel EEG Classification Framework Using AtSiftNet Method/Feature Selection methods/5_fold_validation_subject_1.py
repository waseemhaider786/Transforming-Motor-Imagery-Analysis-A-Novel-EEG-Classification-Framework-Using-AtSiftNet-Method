# -*- coding: utf-8 -*-
"""
Created on Wed Nov  8 18:34:02 2023

@author: wasee
"""

import numpy as np
import csv
from sklearn import svm
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold








def evaluate_svm_classifier(class_1_features, class_2_features):
    # Feature extraction
    feature_matrix = np.vstack((class_1_features, class_2_features))
    output_vector = np.hstack((np.ones(class_1_features.shape[0]), -1 * np.ones(class_2_features.shape[0])))
    #print(feature_matrix)


    # Data normalization
    scaler = StandardScaler()
    normalized_feature_matrix = scaler.fit_transform(feature_matrix)

    # Create an SVM classifier
    SVM_model = svm.SVC(kernel='rbf', C=1, gamma='scale')

    
    # Create a 5-fold StratifiedKFold splitter
    kf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    # Initialize lists to store results for each fold
    accuracy_scores = []
    sensitivity_scores = []
    specificity_scores = []

    for train_index, test_index in kf.split(normalized_feature_matrix, output_vector):
        X_train_svm, X_test_svm = normalized_feature_matrix[train_index], normalized_feature_matrix[test_index]
        y_train_svm, y_test_svm = output_vector[train_index], output_vector[test_index]

        # Train the SVM classifier
        SVM_model.fit(X_train_svm, y_train_svm)

        # Test the SVM classifier
        predicted_labels = SVM_model.predict(X_test_svm)

        # Calculate the accuracy
        accuracy = accuracy_score(y_test_svm, predicted_labels) * 100

        # Calculate the confusion matrix
        conf_matrix = confusion_matrix(y_test_svm, predicted_labels)

        # Calculate sensitivity (recall) and specificity
        TP = conf_matrix[0, 0]
        FN = conf_matrix[0, 1]
        FP = conf_matrix[1, 0]
        TN = conf_matrix[1, 1]

        sensitivity = (TP / (TP + FN)) * 100
        specificity = (TN / (TN + FP)) * 100

        # Append results for this fold to the lists
        accuracy_scores.append(accuracy)
        sensitivity_scores.append(sensitivity)
        specificity_scores.append(specificity)

    # Calculate the mean and standard deviation of the scores
    mean_accuracy = np.mean(accuracy_scores)
    mean_sensitivity = np.mean(sensitivity_scores)
    mean_specificity = np.mean(specificity_scores)

    std_accuracy = np.std(accuracy_scores)
    std_sensitivity = np.std(sensitivity_scores)
    std_specificity = np.std(specificity_scores)

    return mean_accuracy, mean_sensitivity, mean_specificity, std_accuracy, std_sensitivity,std_specificity



import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.metrics import accuracy_score, confusion_matrix


def evaluate_rf_classifier(class_1_features, class_2_features):
    X = np.vstack((class_1_features, class_2_features))
    y = np.hstack((np.ones(class_1_features.shape[0]), -1 * np.ones(class_2_features.shape[0])))

    # Create a Random Forest classifier
    random_forest_classifier = RandomForestClassifier(n_estimators=100, random_state=42)

    # Create a 5-fold StratifiedKFold splitter
    kf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    # Initialize lists to store results for each fold
    accuracy_scores = []
    sensitivity_scores = []
    specificity_scores = []

    for train_index, test_index in kf.split(X, y):
        X_train_RF, X_test_RF = X[train_index], X[test_index]
        y_train_RF, y_test_RF = y[train_index], y[test_index]

        # Fit the classifier to the training data
        random_forest_classifier.fit(X_train_RF, y_train_RF)

        # Make predictions on the test data
        y_pred = random_forest_classifier.predict(X_test_RF)

        # Calculate accuracy
        accuracy = accuracy_score(y_test_RF, y_pred)

        # Calculate confusion matrix
        conf_matrix = confusion_matrix(y_test_RF, y_pred)

        # Calculate sensitivity (recall) and specificity
        true_positives = conf_matrix[1, 1]
        false_negatives = conf_matrix[1, 0]
        true_negatives = conf_matrix[0, 0]
        false_positives = conf_matrix[0, 1]
        sensitivity = true_positives / (true_positives + false_negatives)
        specificity = true_negatives / (true_negatives + false_positives)

        # Append results for this fold to the lists
        accuracy_scores.append(accuracy)
        sensitivity_scores.append(sensitivity)
        specificity_scores.append(specificity)

    # Calculate the mean and standard deviation of the scores
    mean_accuracy = np.mean(accuracy_scores)
    mean_sensitivity = np.mean(sensitivity_scores)
    mean_specificity = np.mean(specificity_scores)

    std_accuracy = np.std(accuracy_scores)
    std_sensitivity = np.std(sensitivity_scores)
    std_specificity = np.std(specificity_scores)
    return mean_accuracy, mean_sensitivity, mean_specificity, std_accuracy, std_sensitivity, std_specificity









# Load data from CSV files
features_from_class_1_MI = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_1_features_Selection_MI.csv', delimiter=',')
features_from_class_2_MI = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_2_features_Selection_MI.csv', delimiter=',')



# Load data from CSV files
features_from_class_1_ReliefF = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_1_features_Selection_ReliefF.csv', delimiter=',')
features_from_class_2_ReliefF = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_2_features_Selection_ReliefF.csv', delimiter=',')





# Load data from CSV files
features_from_class_1_ICA = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_1_features_Selection_ICA.csv', delimiter=',')
features_from_class_2_ICA = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_2_features_Selection_ICA.csv', delimiter=',')




# Load data from CSV files
features_from_class_1_PCA = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_1_features_Selection_PCA.csv', delimiter=',')
features_from_class_2_PCA = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/difficult logic/After Feature Selection CSV/class_2_features_Selection_PCA.csv', delimiter=',')






mean_accuracy_svm_MI, mean_sensitivity_svm_MI, mean_specificity_svm_MI, std_accuracy_svm_MI,std_sensitivity_svm_MI,std_specificity_svm_MI=evaluate_svm_classifier(features_from_class_1_MI, features_from_class_2_MI)

mean_accuracy_rf_MI, mean_sensitivity_rf_MI, mean_specificity_rf_MI, std_accuracy_rf_MI,std_sensitivity_rf_MI,std_specificity_rf_MI=evaluate_rf_classifier(features_from_class_1_MI, features_from_class_2_MI)




mean_accuracy_svm_ReliefF, mean_sensitivity_svm_ReliefF, mean_specificity_svm_ReliefF, std_accuracy_svm_ReliefF,std_sensitivity_svm_ReliefF,std_specificity_svm_ReliefF=evaluate_svm_classifier(features_from_class_1_ReliefF, features_from_class_2_ReliefF)

mean_accuracy_rf_ReliefF, mean_sensitivity_rf_ReliefF, mean_specificity_rf_ReliefF, std_accuracy_rf_ReliefF,std_sensitivity_rf_ReliefF,std_specificity_rf_ReliefF=evaluate_rf_classifier(features_from_class_1_ReliefF, features_from_class_2_ReliefF)





mean_accuracy_svm_ICA, mean_sensitivity_svm_ICA, mean_specificity_svm_ICA, std_accuracy_svm_ICA,std_sensitivity_svm_ICA,std_specificity_svm_ICA=evaluate_svm_classifier(features_from_class_1_ICA, features_from_class_2_ICA)

mean_accuracy_rf_ICA, mean_sensitivity_rf_ICA, mean_specificity_rf_ICA, std_accuracy_rf_ICA,std_sensitivity_rf_ICA,std_specificity_rf_ICA=evaluate_rf_classifier(features_from_class_1_ICA, features_from_class_2_ICA)







mean_accuracy_svm_PCA, mean_sensitivity_svm_PCA, mean_specificity_svm_PCA, std_accuracy_svm_PCA,std_sensitivity_svm_PCA,std_specificity_svm_PCA=evaluate_svm_classifier(features_from_class_1_PCA, features_from_class_2_PCA)

mean_accuracy_rf_PCA, mean_sensitivity_rf_PCA, mean_specificity_rf_PCA, std_accuracy_rf_PCA,std_sensitivity_rf_PCA,std_specificity_rf_PCA=evaluate_rf_classifier(features_from_class_1_PCA, features_from_class_2_PCA)




# Display the results
print('Mean Accuracy of SVM with 5-fold cross-validation by using Mutual Information is: {:.2f}% ± {:.2f}%'.format(mean_accuracy_svm_MI, std_accuracy_svm_MI))
print('Mean Sensitivity of SVM with 5-fold cross-validation by using Mutual Information is: {:.2f}% ± {:.2f}%'.format(mean_sensitivity_svm_MI, std_sensitivity_svm_MI))
print('Mean Specificity of SVM with 5-fold cross-validation by using Mutual Information is: {:.2f}% ± {:.2f}%'.format(mean_specificity_svm_MI, std_specificity_svm_MI))
print('\n')

# Display the results
print('Mean Accuracy of RF with 5-fold cross-validation by using Mutual Information is: {:.2f}% ± {:.2f}%'.format(mean_accuracy_rf_MI*100, std_accuracy_rf_MI*100))
print('Mean Sensitivity of RF with 5-fold cross-validation by using Mutual Information is: {:.2f}% ± {:.2f}%'.format(mean_sensitivity_rf_MI*100, std_sensitivity_rf_MI*100))
print('Mean Specificity of RF with 5-fold cross-validation by using Mutual Information is: {:.2f}% ± {:.2f}%'.format(mean_specificity_rf_MI*100, std_specificity_rf_MI*100))
print('\n')





# Display the results
print('Mean Accuracy of SVM with 5-fold cross-validation by using ReliefF is: {:.2f}% ± {:.2f}%'.format(mean_accuracy_svm_ReliefF, std_accuracy_svm_ReliefF))
print('Mean Sensitivity of SVM with 5-fold cross-validation by using ReliefF is: {:.2f}% ± {:.2f}%'.format(mean_sensitivity_svm_ReliefF, std_sensitivity_svm_ReliefF))
print('Mean Specificity of SVM with 5-fold cross-validation by using ReliefF is: {:.2f}% ± {:.2f}%'.format(mean_specificity_svm_ReliefF, std_specificity_svm_ReliefF))
print('\n')

# Display the results
print('Mean Accuracy of RF with 5-fold cross-validation by using ReliefF is: {:.2f}% ± {:.2f}%'.format(mean_accuracy_rf_ReliefF*100, std_accuracy_rf_ReliefF*100))
print('Mean Sensitivity of RF with 5-fold cross-validation by using ReliefF is: {:.2f}% ± {:.2f}%'.format(mean_sensitivity_rf_MI*100, std_sensitivity_rf_ReliefF*100))
print('Mean Specificity of RF with 5-fold cross-validation by using ReliefF is: {:.2f}% ± {:.2f}%'.format(mean_specificity_rf_ReliefF*100, std_specificity_rf_ReliefF*100))
print('\n')







# Display the results
print('Mean Accuracy of SVM with 5-fold cross-validation by using ICA is: {:.2f}% ± {:.2f}%'.format(mean_accuracy_svm_ICA, std_accuracy_svm_ICA))
print('Mean Sensitivity of SVM with 5-fold cross-validation by using ICA is: {:.2f}% ± {:.2f}%'.format(mean_sensitivity_svm_ICA, std_sensitivity_svm_ICA))
print('Mean Specificity of SVM with 5-fold cross-validation by using ICA is: {:.2f}% ± {:.2f}%'.format(mean_specificity_svm_ICA, std_specificity_svm_ICA))
print('\n')

# Display the results
print('Mean Accuracy of RF with 5-fold cross-validation by using ICA is: {:.2f}% ± {:.2f}%'.format(mean_accuracy_rf_ICA*100, std_accuracy_rf_ICA*100))
print('Mean Sensitivity of RF with 5-fold cross-validation by using ICA is: {:.2f}% ± {:.2f}%'.format(mean_sensitivity_rf_ICA*100, std_sensitivity_rf_ICA*100))
print('Mean Specificity of RF with 5-fold cross-validation by using ICA is: {:.2f}% ± {:.2f}%'.format(mean_specificity_rf_ICA*100, std_specificity_rf_ICA*100))
print('\n')





# Display the results
print('Mean Accuracy of SVM with 5-fold cross-validation by using PCA is: {:.2f}% ± {:.2f}%'.format(mean_accuracy_svm_PCA, std_accuracy_svm_PCA))
print('Mean Sensitivity of SVM with 5-fold cross-validation by using PCA is: {:.2f}% ± {:.2f}%'.format(mean_sensitivity_svm_PCA, std_sensitivity_svm_PCA))
print('Mean Specificity of SVM with 5-fold cross-validation by using PCA is: {:.2f}% ± {:.2f}%'.format(mean_specificity_svm_PCA, std_specificity_svm_PCA))
print('\n')

# Display the results
print('Mean Accuracy of RF with 5-fold cross-validation by using PCA is: {:.2f}% ± {:.2f}%'.format(mean_accuracy_rf_PCA*100, std_accuracy_rf_PCA*100))
print('Mean Sensitivity of RF with 5-fold cross-validation by using PCA is: {:.2f}% ± {:.2f}%'.format(mean_sensitivity_rf_PCA*100, std_sensitivity_rf_PCA*100))
print('Mean Specificity of RF with 5-fold cross-validation by using PCA is: {:.2f}% ± {:.2f}%'.format(mean_specificity_rf_PCA*100, std_specificity_rf_PCA*100))
print('\n')