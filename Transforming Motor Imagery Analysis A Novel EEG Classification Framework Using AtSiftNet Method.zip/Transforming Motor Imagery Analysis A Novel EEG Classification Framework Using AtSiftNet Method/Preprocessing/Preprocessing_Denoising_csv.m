 %Waseem Haider
%2021280065
close all;
clear all;
clc;


%Loading the data
%Data=load(fullfile(tempdir,'data_set_IVa_aa'));

EEGdata=load(fullfile('G:/Course Ms/Research/MATLAB/data set IVa/Subject 1/100Hz/data_set_IVa_aa'));

%separate the data
pos_data=EEGdata.mrk.pos;
y_data=EEGdata.mrk.y;
Class_name=EEGdata.mrk.className;
sampling_freq=EEGdata.nfo.fs;
original_data_cnt=EEGdata.cnt;
%original_data_cnt=0.1*double(original_data);


class_1=[];
class_2=[];
max=168;
final_class_1=[];
final_class_2=[];

%Final_right_foot_data_Row=[];
for i=1:max
    if(y_data(:,i)==1)
        initial_index_class_1=pos_data(:,i);
        
        final_index_class_1=pos_data(:,i)+(sampling_freq*3.5);
        
        pick_up_rows_class_1=initial_index_class_1:final_index_class_1;
        
        class_1=original_data_cnt(pick_up_rows_class_1,:);
        
        %concatenation or stacking of the two matrices
        final_class_1=[final_class_1;class_1];
        
        
        
    
    else 
        initial_index_class_2=pos_data(:,i);
        
        final_index_class_2=pos_data(:,i)+(sampling_freq*3.5);
        
        pick_up_rows_class_2=initial_index_class_2:final_index_class_2;
        
        class_2=original_data_cnt(pick_up_rows_class_2,:);
        
        %concatenation or stacking of the two matrices
        final_class_2=[final_class_2;class_2];
        
    end
        
        
    
end
 %remove extra rows to make both classes equal so we can combine them

final_class_2_Eliminate_Rows=  final_class_2(1:end-2808, :);

disp("1. The sorting of data is done: Please check the workspace");

%So here for  we manually select 18 channels, that are C5, C3, C1, C2, C4, C6,
%CP5, CP3, CP1, CP2, CP4, CP6, P5, P3, P1, P2, P4 and P6.
%So according to my dataset
% Channel Name   Cnt Index   Class 
%   C5             51          2          
%   C3             52          2          
%   C1             53          1          
%   C2             55          1          
%   C4             56          1          
%   C6             57          2          
%   CP5            69          1          
%   CP3            70          2          
%   CP1            71          2          
%   CP2            73          1          
%   CP4            74          1          
%   CP6            75          2          
%   P5             88          2          
%   P3             89          2          
%   P1             90          2          
%   P2             92          2          
%   P4             93          1          
%   P6             94          2    

%Selecting the above specified channel from our sorted data
%First Extract the channels from class 1
columns_to_extract_from_class_1=[51 52 53 55 56 57 69 70 71 73 74 75 88 89 90 92 93 94];
Extracted_channels_from_class_1=final_class_1(:, columns_to_extract_from_class_1);

%Now Extract the channels form class 2
columns_to_extract_from_class_2=[51 52 53 55 56 57 69 70 71 73 74 75 88 89 90 92 93 94];
Extracted_channels_from_class_2=final_class_2_Eliminate_Rows(:, columns_to_extract_from_class_2);

disp("2. The extraction of specific columns from data is done: Please check the workspace");


%Converting the int16 input matrix in double
 double_Extracted_channels_from_class_1 = double(Extracted_channels_from_class_1);
 double_Extracted_channels_from_class_2 = double(Extracted_channels_from_class_2);


%Now denoised the both Channel by using wmspca
 %Applying WMSPCA for denousing for class 1
 level_class_1=5;
 name_of_wavelet_used_class_1='sym24';
 num_of_principal_component_class_1='heur';
 [Denoised_Final_Extracted_channels_from_class_1,quality_of_denoised_signal_class_1,retained_PC_class_1]=wmspca(double_Extracted_channels_from_class_1,level_class_1, name_of_wavelet_used_class_1, num_of_principal_component_class_1);
 %%%%% double_Extracted_channels_from_class_1,level_class_1: This is the input EEG signal that will undergo the WMSPCA operation. It is a matrix of double-precision
%  floating-point values where each row represents a sample (i.e., a time point) and each column represents a channel (i.e., an electrode) of the EEG data. 
%  The variable name suggests that this data has already been extracted and processed from both classes (class 1 and class 2).

%%%%% level_class_1: This parameter specifies the number of decomposition levels in the wavelet transform that will be applied to the EEG data. A higher value of level results
% in a finer resolution of the signal in the time-frequency domain but also increases computational complexity.

%%%%% name_of_wavelet_used_class_1: This is the name of the wavelet function that will be used for the wavelet transform. Examples of wavelet functions include db10,
% sym4, sym24 etc.

%%%%% num_of_principal_component_class_1: This parameter specifies the number of principal components that will be retained after the WMSPCA operation. Principal component
% analysis (PCA) is a technique that reduces the dimensionality of the data by identifying the directions of maximum variance. Retaining only a subset of the
% principal components can reduce noise and redundancy in the signal.
 


%%%%%Denoised_Final_Extracted_channels_from_class_1: This is the denoised EEG signal after the WMSPCA operation. It is a matrix of double-precision floating-point
% values with the same dimensions as the input signal.

%%%%% quality_of_denoised_signal_class_1: This is a scalar value that represents the quality of the denoised signal. The higher the value, the better the quality of the
% denoised signal.

%%%%% retained_PC_class_1: This is a matrix of double-precision floating-point values that represents the retained principal components after the WMSPCA operation. It has 
% num_of_principal_component columns, where each column represents a principal component.


 
 
 %Now Applying WMSPCA for denousing for class 2
 level_class_2=5;
 name_of_wavelet_used_class_2='sym24';
 num_of_principal_component_class_2='heur';
 [Denoised_Final_Extracted_channels_from_class_2,quality_of_denoised_signal_class_2,retained_PC_class_2]=wmspca(double_Extracted_channels_from_class_2,level_class_2, name_of_wavelet_used_class_2, num_of_principal_component_class_2);
 
disp("3. Sucessfully denoised the data of both classes! Check Now the signal quality in workspace and graphs");

matrix = Denoised_Final_Extracted_channels_from_class_1;
filename = 'F:\Course Ms\Research\MATLAB\From CSV\My orginal\Preprocessed CSV\Preprocessed_Class_1.csv';
csvwrite(filename, matrix);


matrix = Denoised_Final_Extracted_channels_from_class_2;
filename = 'F:\Course Ms\Research\MATLAB\From CSV\My orginal\Preprocessed CSV\Preprocessed_Class_2.csv';
csvwrite(filename, matrix);

matrix = double_Extracted_channels_from_class_1;
filename = 'F:\Course Ms\Research\MATLAB\From CSV\My orginal\Preprocessed CSV\noised_Class_1.csv';
csvwrite(filename, matrix);


matrix = double_Extracted_channels_from_class_2;
filename = 'F:\Course Ms\Research\MATLAB\From CSV\My orginal\Preprocessed CSV\noised_Class_2.csv';
csvwrite(filename, matrix);
disp("CSV file updated.....!")

