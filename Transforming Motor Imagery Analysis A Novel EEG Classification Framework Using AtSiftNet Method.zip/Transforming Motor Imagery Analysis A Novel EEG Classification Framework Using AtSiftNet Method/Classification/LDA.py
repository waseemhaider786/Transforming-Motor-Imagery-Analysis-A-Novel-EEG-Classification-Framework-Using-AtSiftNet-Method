# -*- coding: utf-8 -*-
"""
Created on Fri Oct  6 17:44:27 2023

@author: wasee
"""

import numpy as np
import csv
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix



# Load data from CSV files
features_from_class_1 = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/class_1_features_Selection_RFA.csv', delimiter=',')
features_from_class_2 = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/class_2_features_Selection_RFA.csv', delimiter=',')




# Scatter plot
import matplotlib.pyplot as plt

plt.scatter(features_from_class_1[:, 2], features_from_class_1[:, 3], marker='o', label='Class 1')
plt.scatter(features_from_class_2[:, 2], features_from_class_2[:, 3], marker='x', label='Class 2')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.title('Cluster Visualization')
plt.legend(loc='best')





# Feature extraction
feature_matrix = np.vstack((features_from_class_1, features_from_class_2))
output_vector = np.hstack((np.ones(features_from_class_1.shape[0]), -1 * np.ones(features_from_class_2.shape[0])))




# Data normalization
scaler = StandardScaler()
normalized_feature_matrix = scaler.fit_transform(feature_matrix)




# Split data into training and testing sets (70-30 split)
train_data, test_data, train_labels, test_labels = train_test_split(
    normalized_feature_matrix, output_vector, test_size=0.3, random_state=42
)




# Train the LDA classifier
lda_model = LDA()
lda_model.fit(train_data, train_labels)





# Test the LDA classifier
predicted_labels = lda_model.predict(test_data)



# Calculate the accuracy
accuracy = accuracy_score(test_labels, predicted_labels) * 100




# Calculate the confusion matrix
conf_matrix = confusion_matrix(test_labels, predicted_labels)
print(conf_matrix)


# Calculate sensitivity (recall) and specificity
TP = conf_matrix[0, 0]
FN = conf_matrix[0, 1]
FP = conf_matrix[1, 0]
TN = conf_matrix[1, 1]

sensitivity = TP / (TP + FN) * 100
specificity = TN / (TN + FP) * 100



# Display the results
print(f'Accuracy of Linear Discriminant Analysis (LDA) is: {accuracy:.2f}%')
print(f'Sensitivity of Linear Discriminant Analysis (LDA) is: {sensitivity:.2f}%')
print(f'Specificity of Linear Discriminant Analysis (LDA) is: {specificity:.2f}%')




