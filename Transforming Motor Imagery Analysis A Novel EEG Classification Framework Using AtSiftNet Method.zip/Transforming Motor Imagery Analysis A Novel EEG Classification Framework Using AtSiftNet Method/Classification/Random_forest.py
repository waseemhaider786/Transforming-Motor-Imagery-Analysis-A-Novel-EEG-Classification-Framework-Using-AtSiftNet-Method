# -*- coding: utf-8 -*-
"""
Created on Thu Nov  9 11:35:56 2023

@author: wasee
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Oct  5 15:45:35 2023

@author: wasee
"""

import numpy as np


from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix



from sklearn.ensemble import RandomForestClassifier





# Load data from CSV files
features_from_class_1 = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/Subject 2/Python/Self Attention/class_1_features_Extraction.csv', delimiter=',')
features_from_class_2 = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/Subject 2/Python/Self Attention/class_2_features_Extraction.csv', delimiter=',')



import matplotlib.pyplot as plt

plt.scatter(features_from_class_1[0:350, 0], features_from_class_1[0:350, 1], marker='o', label='Class 1')
plt.scatter(features_from_class_2[0:350, 0], features_from_class_2[0:350, 1], marker='x', label='Class 2')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.title('Cluster Visualization')
plt.legend(loc='best')




X = np.vstack((features_from_class_1, features_from_class_2))
y = np.hstack((np.ones(features_from_class_1.shape[0]), -1 * np.ones(features_from_class_2.shape[0])))

X_train_RF, X_test_RF, y_train_RF, y_test_RF = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a Random Forest classifier
random_forest_classifier = RandomForestClassifier(n_estimators=100, random_state=42)

# Fit the classifier to the training data
random_forest_classifier.fit(X_train_RF, y_train_RF)



# Make predictions on the test data
y_pred = random_forest_classifier.predict(X_test_RF)

# Calculate accuracy and display classification report
accuracy = accuracy_score(y_test_RF, y_pred)

# Calculate confusion matrix to compute sensitivity and specificity
conf_matrix = confusion_matrix(y_test_RF, y_pred)

# Calculate sensitivity (recall) and specificity
true_positives = conf_matrix[1, 1]
false_negatives = conf_matrix[1, 0]
true_negatives = conf_matrix[0, 0]
false_positives = conf_matrix[0, 1]
sensitivity = true_positives / (true_positives + false_negatives)
specificity = true_negatives / (true_negatives + false_positives)

print(f"Accuracy of Random Forest: {accuracy * 100}%")
print(f"Sensitivity of Random Forest: {sensitivity * 100:.2f}%")
print(f"Specificity of Random Forest: {specificity * 100:.2f}%")