# -*- coding: utf-8 -*-
"""
Created on Fri Oct  6 17:55:00 2023

@author: wasee
"""
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, classification_report
from sklearn.metrics import accuracy_score, confusion_matrix




# Load data from CSV files
features_from_class_1 = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/class_1_features_Selection_PCA.csv', delimiter=',')
features_from_class_2 = np.genfromtxt('F:/Course Ms/Research\MATLAB/From CSV/My orginal/Python/Self Attention/class_2_features_Selection_PCA.csv', delimiter=',')




# Scatter plot
import matplotlib.pyplot as plt

plt.scatter(features_from_class_1[:, 2], features_from_class_1[:, 3], marker='o', label='Class 1')
plt.scatter(features_from_class_2[:, 2], features_from_class_2[:, 3], marker='x', label='Class 2')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.title('Cluster Visualization')
plt.legend(loc='best')



X = np.vstack((features_from_class_1, features_from_class_2))
y = np.hstack((np.ones(features_from_class_1.shape[0]), -1 * np.ones(features_from_class_2.shape[0])))



X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)



# Create a KNN classifier with a specified number of neighbors
k = 2
knn_classifier = KNeighborsClassifier(n_neighbors=k)



# Fit the classifier to the training data
knn_classifier.fit(X_train, y_train)




# Make predictions on the test data
y_pred = knn_classifier.predict(X_test)





# Calculate accuracy and display classification report
accuracy = accuracy_score(y_test, y_pred)
# Calculate confusion matrix to compute sensitivity and specificity
conf_matrix = confusion_matrix(y_test, y_pred)
# Calculate sensitivity (recall) and specificity
true_positives = conf_matrix[1, 1]
false_negatives = conf_matrix[1, 0]
true_negatives = conf_matrix[0, 0]
false_positives = conf_matrix[0, 1]
sensitivity = true_positives / (true_positives + false_negatives)
specificity = true_negatives / (true_negatives + false_positives)





print(f"Accuracy: {accuracy*100}%")
print(f"Sensitivity : {sensitivity*100:.2f}%")
print(f"Specificity: {specificity*100:.2f}%")
