# -*- coding: utf-8 -*-
"""
Created on Mon Oct  9 17:51:42 2023

@author: wasee
"""

import pandas as pd

# Read the CSV files
features = pd.read_csv('F:/Course Ms/Research/MATLAB/From CSV/My orginal/Features From Alex CSV/DWT EMD Hilbert/sgdm/features.csv', header=None)
labels = pd.read_csv('F:/Course Ms/Research/MATLAB/From CSV/My orginal/Features From Alex CSV/DWT EMD Hilbert/sgdm/label.csv', header=None)

features_class_1 = []
features_class_2 = []

for i in range(2304):
    if labels.iloc[i, 0] == 1:
        features_class_1.append(features.iloc[i, :4096])
    else:
        features_class_2.append(features.iloc[i, :4096])

final_features_class_1 = pd.concat(features_class_1, axis=1).T
final_features_class_2 = pd.concat(features_class_2, axis=1).T

# Save the data to CSV files
final_features_class_1.to_csv('F:/Course Ms/Research/MATLAB/From CSV/My orginal/Features From Alex CSV/DWT EMD Hilbert/sgdm/Features_class_1.csv', index=False, header=False)
final_features_class_2.to_csv('F:/Course Ms/Research/MATLAB/From CSV/My orginal/Features From Alex CSV/DWT EMD Hilbert/sgdm/Features_class_2.csv', index=False, header=False)

print("CSV files updated...")
