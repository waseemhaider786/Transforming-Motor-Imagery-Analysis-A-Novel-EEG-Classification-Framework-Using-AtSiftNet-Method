# -*- coding: utf-8 -*-
"""
Created on Thu Oct  5 15:45:35 2023

@author: wasee
"""

import numpy as np
import csv
from sklearn import svm
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix



# Load data from CSV files
features_from_class_1 = np.genfromtxt('G:/Course Ms/Research/MATLAB/From CSV/My orginal/Features From Alex CSV/CWT DWT EMD/rmsprop/Features_class_1.csv', delimiter=',')
features_from_class_2 = np.genfromtxt('G:/Course Ms/Research/MATLAB/From CSV/My orginal/Features From Alex CSV/CWT DWT EMD/rmsprop/Features_class_2.csv', delimiter=',')



import matplotlib.pyplot as plt

plt.scatter(features_from_class_1[0:350, 12], features_from_class_1[0:350, 13], marker='o', label='Class 1')
plt.scatter(features_from_class_2[0:350, 12], features_from_class_2[0:350, 13], marker='x', label='Class 2')
plt.xlabel('Feature 1', fontsize=14, fontweight='bold')  # Bold and larger font size for x-axis label
plt.ylabel('Feature 2', fontsize=14, fontweight='bold')  # Bold and larger font size for y-axis label
#plt.title('Cluster Visualization', fontsize=16, fontweight='bold')  # Bold and larger font size for title
plt.legend(loc='best', fontsize=12)  # Increase font size for legend
plt.xticks(fontsize=12, fontweight='bold')  # Bold and larger font size for x-axis ticks
plt.yticks(fontsize=12, fontweight='bold')  # Bold and larger font size for y-axis ticks
plt.show()




# Feature extraction
feature_matrix = np.vstack((features_from_class_1, features_from_class_2))
output_vector = np.hstack((np.ones(features_from_class_1.shape[0]), -1 * np.ones(features_from_class_2.shape[0])))
#print(feature_matrix)


# Data normalization
scaler = StandardScaler()
normalized_feature_matrix = scaler.fit_transform(feature_matrix)


# Split data into training and testing sets (70-30 split)
train_data, test_data, train_labels, test_labels = train_test_split(
    normalized_feature_matrix, output_vector, test_size=0.3, random_state=42
)



# Train the SVM classifier
SVM_model = svm.SVC(kernel='rbf', C=1, gamma='scale')
SVM_model.fit(train_data, train_labels)


# Test the SVM classifier
predicted_labels = SVM_model.predict(test_data)





# Calculate the accuracy
accuracy = accuracy_score(test_labels, predicted_labels) * 100




# Calculate the confusion matrix
conf_matrix = confusion_matrix(test_labels, predicted_labels)
print(conf_matrix)




# Calculate sensitivity (recall) and specificity
TP = conf_matrix[0, 0]
FN = conf_matrix[0, 1]
FP = conf_matrix[1, 0]
TN = conf_matrix[1, 1]




sensitivity = (TP / (TP + FN)) * 100
specificity = (TN / (TN + FP)) * 100




# Display the results
print(f'Accuracy of Support Vector Machine (SVM) is: {accuracy:.2f}%')
print(f'Sensitivity of Support Vector Machine (SVM) is: {sensitivity:.2f}%')
print(f'Specificity of Support Vector Machine (SVM) is: {specificity:.2f}%')










